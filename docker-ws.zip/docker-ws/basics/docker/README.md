# TODO

* Aufgaben:
  * `docker run hello-world` ausführen, Ausgabe analysieren
