# Wichtige Konzepte:

THEORIE! Keine Aufgabe

* Image
* Ports
* Environment
* Volume

* Wichte docker-compose CLI commands